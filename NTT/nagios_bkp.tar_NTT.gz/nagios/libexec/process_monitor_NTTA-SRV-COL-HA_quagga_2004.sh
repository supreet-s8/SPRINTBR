#!/bin/bash

/usr/local/nagios/libexec/new_runcmd.sh /data/nagios_bgp/command 192.168.10.200 30004

sleep 10

#perl /usr/local/nagios/libexec/quagga_monitoring.pl 2001

perl /usr/local/nagios/libexec/quagga.pl 30004
