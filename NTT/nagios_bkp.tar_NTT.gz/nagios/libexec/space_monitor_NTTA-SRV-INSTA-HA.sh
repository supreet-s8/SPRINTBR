#!/bin/bash
perl /usr/local/nagios/libexec/AutoSSh_monitor_check.pl /usr/local/nagios/libexec/customerInfo.cfg NTTA-SRV-INSTA-HA -s /,/data,/var,/data/Calpont/backup/data1,/data/Calpont/backup/data2,/data/Calpont/backup/data3,/data/Calpont/backup/data4 
