#!/bin/bash
perl /usr/local/nagios/libexec/AutoSSh_monitor_check.pl /usr/local/nagios/libexec/customerInfo.cfg NTTA-SRV-INSTA-002 -s /,/data,/var,/guavus/insta,/usr/local/Calpont/data1,/usr/local/Calpont/data2,/usr/local/Calpont/data3,/usr/local/Calpont/data4
