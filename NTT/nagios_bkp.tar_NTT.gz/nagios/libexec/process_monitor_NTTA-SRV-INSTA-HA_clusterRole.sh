#!/bin/bash
perl /usr/local/nagios/libexec/AutoSSh_monitor_check.pl /usr/local/nagios/libexec/customerInfo.cfg GNS3-SRV-INS-001 -p clusterRole
