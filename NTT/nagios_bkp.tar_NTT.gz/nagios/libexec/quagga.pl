#!/usr/local/bin/perl

$port=$ARGV[0];

use Net::Telnet ();

my($prompt, $hostname, $password, $enable);
my($interval) = 300;
my($statefn) = '';
my($debugdir) = '';
my($peercnt);
my($peerconfcnt) = 0;
my(%ip2as);
my(%peer);
my(%peerprio);
my(%peerlvl);
my($res);
my($failres) = '';
my($saveres) = '';
my($myas) = '';
my($alert);

# variables
my($pre, $mat);
my(@pre);
my($t);
my($i);
my($r);
my($err);

###########

$t = new Net::Telnet (
    Timeout => 1,
    Binmode => 1,
    Port => $port,
    Telnetmode => 10,
    Errmode => "return",
);

$r = $t->open('192.168.10.200');
if ( !defined($r) ) {
    print "BGP CRITICAL - no-connection\n";
    exit(2);
}

$t->waitfor(String => "Password: ");
$err = $t->errmsg;
if ( $err ne '' ) {
    print "BGP CRITICAL - waitforpw: $err\n";
    exit(2);
};
#$t->print(Gur9a0n);
$t->print(zebra);
$t->waitfor(String => "$prompt> ");
$err = $t->errmsg;
if ( $err ne '' ) {
    print "BGP CRITICAL - waitforprompt1: $err\n";
    exit(2);
};
$t->print("enable");
#$t->waitfor(String => "Password: ");
#$err = $t->errmsg;
#if ( $err ne '' ) {
#    print "BGP CRITICAL - waitforprompt2: $err\n";
#    exit(2);
#};

#$t->print(Gur9a0n);
$t->prompt('/'.$prompt.'# /');

$err = $t->errmsg;
if ( $err ne '' ) {
    print "BGP CRITICAL - waitforprompt3: $err\n";
    exit(2);
};

#########
open (CMD,'/data/nagios_bgp/command') || die "$! \n";

while ($line=<CMD>){

chomp($line);


if ( $line eq 'show running-config' ){

$res = &parseconf($line);
if ( $res ne '' ) {
    print "BGP CRITICAL - $res|-\n"; 
    exit(2);
}
}

if ( $line eq 'show bgp mem' ){

$res = &parsemem($line);

}

if ( $line eq 'show ip bgp summary' ){

$res .= &parsebgpsum($line);

}

if ( $line eq 'show ipv6 bgp summary' ){

$res .= &parsebgpsum($line);

}

}

close(CMD);


#print "$failres \n";

if ( $failres =~ /crit=/ || $peercnt != $peerconfcnt ) {
    $alert='CRITICAL';
}
elsif ( $failres =~ /warn=/ ) {
    $alert='WARNING';
}
else {
    $alert='OK';
}

if ( $failres ne '' ) {

    print "BGP $alert - $failres | $res\n";
}
else {
    print "BGP $alert | $res\n";
}

if ( $alert eq 'CRITICAL' ) {
    exit(2);
}
elsif ( $alert eq 'WARNING' ) {
    exit(1);
}
exit 0;

#####################################################################

sub parseconf {
    #my(@pre)= @_;
	$l=shift;
	$l =~ s/\s//g;
    my($ip, $as, $peer, $prio, $ipas);
    my(@t);

	
open (IN1,"/usr/local/nagios/libexec/${port}_output_$l.txt") || die "no file $! \n";
	my(@pre)= <IN1>;

    foreach $i (0..$#pre) {
#	print "$i: $pre[$i]\n";
	chomp($pre[$i]);
	# find my own AS
	if ( $pre[$i] =~ m/^router bgp \d+$/ ) {
	    if ( $myas eq '' ) {
		( $myas ) = ( $pre[$i] =~ /^router bgp (\d+)$/ );
	    }
	    else {
		return "parseconf: found second bgp router in line $i";
	    }
	    next;
	}

	# find peers
	if ( $pre[$i] =~ /^ neighbor [0-9a-f\.:]+ remote-as \d+$/ ) {

	    ( $ip, $as ) = ( $pre[$i] =~ /^ neighbor ([0-9a-f\.:]+) remote-as (\d+)$/ );
	    if ( !defined($ip) || !defined($as) ) {

		return "parseconf: did not find IP and AS in line $i";
	    }
	    if ( defined($ip2as{$ip}) ) {
		return "parseconf: found IP and AS a second time in line $i";
	    }
	    else {
		$ip2as{$ip} = $as;
		# preset some values, if no description is found
		$ipas = $ip.' '.$ip2as{$ip};
		$peer{$ipas} = 'unknown'.$peerconfcnt;
		$peerlvl{$ipas} = $peerconfcnt;
		$peerprio{$ipas} = 'crit';
		$peerconfcnt++;
	    }
	    next;
	}

	# find description, prio
	if ( $pre[$i] =~ /^ neighbor [0-9a-f\.:]+ description / ) {
	    @t = split(/\s+/,$pre[$i]);
	    $ip = $t[2];
	    $peer = $t[4];
	    $prio = $t[5];
	    # print "$ip $peer $prio\n";
	    if ( !defined($ip) || !defined($peer) ) {
		return "parseconf: did not find IP and peername in line $i";
	    }
	    if ( !defined($ip2as{$ip}) ) {

		return "parseconf: did not find AS for IP $ip in line $i";
		next;
	    }
	    $ipas = $ip.' '.$ip2as{$ip};
	    $peer{$ipas} = $peer;
	    $peerlvl{$ipas} = $peerconfcnt;
	    if ( defined($prio) ) {
		# TODO: check on valid values 'warn, crit, low'
		$peerprio{$ipas} = $prio;
	    }
	    else {
		$peerprio{$ipas} = 'crit';
	    }

	#     print "peer: $peer ip: $ip as: $as\n";
	    next;
	}
    }

    return '';
close(IN1);
}

sub parsemem {
    #my(@pre)= @_;

    my($ncnt);
    # search for '\d+ peers, using \d+ \S+ of memory' line

	$l=shift;
	$l =~ s/\s//g;

	open (IN1,"/usr/local/nagios/libexec/${port}_output_$l.txt") || die "no file $! \n";
	my(@pre)= <IN1>;

    foreach $i (@pre) {
	# print "i: $i\n";
	if ( $i =~ /\d+ peers, using \d+ \S+ of memory/ ) {
	    ( $ncnt ) = ( $i =~ /(\d+) peers, using \d+ \S+ of memory/ );
	    if ( defined($ncnt) ) {
		$ncnt--;
		$peercnt=$ncnt;
		if ( $peercnt == $peerconfcnt ) {
		    return "neigh=$ncnt ";
		}
		else {
		    return "neigh=$ncnt;;;$peerconfcnt; ";
		}
	    }
        }
    }
close(IN1);

}

sub parsebgpsum {
    #my(@pre)= @_;
    my($ip,$as,$upt,$pfx);
    my($off, $t);
    my($res)='';
    my($mode)='';

    $l=shift;

    if ( $l eq 'show ip bgp summary' ) {
	$mode='v4';
    }
    elsif ( $l eq 'show ipv6 bgp summary' ) {
	$mode='v6';
    }
    else {
	# print $pre[0]."\n";
	$failres='unknown-mode';
	return '';
    }

    $l =~ s/\s//g;

 	open (IN1,"/usr/local/nagios/libexec/${port}_output_$l.txt") || die "no file $! \n";
    my(@pre)= <IN1>;

    foreach $i (0..$#pre) {
	# print $mode.": $pre[$i]\n";

	if ( $pre[$i] =~ /^([0-9a-f\.:]+)/ ) {

	    ( $ip ) = ( $pre[$i] =~ /^([0-9a-f\.:]+)/ );
	    # which line do we have to parse ?
	    if ( defined($ip) ) {
		if ( length($ip) > 15 ) {
		    $t = substr($pre[$i+1],18);
		}
		else {
		    $t = substr($pre[$i],18);
		}
		# parse the line
		# print $mode."m: $t\n";
		my(@t)=split(/\s+/,$t);
		if ( $t[0] eq '' ) {
		    shift(@t);
		}
		$as = $t[0];
		$upt= upt2sec($t[6]);
		# print "ip: $ip as: $as\n";
		if ( $upt < $interval ) {
		    $failres .= $mode."age-".$peer{"$ip $as"}."=".$peerlvl{"$ip $as"}.' ';
		}
		$pfx= $t[7];

#print "$pfx\n";
		if ( $pfx !~ /^\d+$/ ) {
		    # Active, Idle, OpenSent or something else ?
		    $failres .= $peerprio{"$ip $as"}.'='.$peer{"$ip $as"}.':'.$pfx.' ';

		}
	# print $mode."p: $ip $as $upt $pfx\n";

		# output in nagios plugin syntax
		# if ( $ip =~ /:/ && $pfx != 0 ) {
		    $saveres .= $mode."rt-".$peer{"$ip $as"}."=$pfx ";
		# }
	    }
	    else {
		# we can not parse this line, skip it
		next;
	    }
        }
	else {
	    next;
	}
    }

    return $res;
close(IN1);
}


sub upt2sec {
    my($inp) = @_;

    # examples: never, 01:43:22, 1d00h57m, 05w4d23h

    # print "inp: $inp\n";
    if ( $inp eq 'never' ) {
	return -1;
    }

    if ( $inp =~ /:/ ) {
	my($h,$m,$s) = split(/:/,$inp);
	if ( !defined($h) ) {
	    return -1;
	}
	return $h * 3600 + $m * 60 + $s;
    }

    if ( $inp =~ /\d+d\d+h\d+m/ ) {
	my($d,$h,$m) = ( $inp =~ /^(\d+)d(\d+)h(\d+)m$/ );
	if ( !defined($d) ) {
	    return -1;
	}
	return $d * 86400 + $h * 3600 + $m * 60;
    }

    if ( $inp =~ /\d+w\d+d\d+h/ ) {
	my($w,$d,$h) = ( $inp =~ /^(\d+)w(\d+)d(\d+)h$/ );
	if ( !defined($w) ) {
	    return -1;
	}
	return $w * 604800 + $d * 86400 + $h * 3600;
    }

    # if we can not parse it, return -1
    return -1;

}
