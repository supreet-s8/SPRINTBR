#!/usr/bin/perl -w

use Expect;
use IO::Pty;
use Switch;
use Net::SSH::Perl;
use Net::SSH::Perl::Key::RSA;
use Class::ErrorHandler;

if( (! defined $ARGV[0] ) || (!defined $ARGV[1]) ) 
{
	print "Usage: AutoSSh.pl  <ConfigFile> < customer> \n";
	exit;
}

$CName=$ARGV[1];
@time_el=localtime(time);
$YY=$time_el[5]+1900;
$MM=$time_el[4]+1; #$MM="0"."$MM" if ( $MM lt 10);
$DD=$time_el[3];   #$DD="0"."$DD" if ( $DD lt 10);
$HH=$time_el[2];   #$HH="0"."$HH" if ( $HH lt 10);
$mm=$time_el[1];   #$mm="0"."$mm" if ( $mm lt 10);

$ssh_file="/tmp/$CName/$YY$MM$DD$HH$mm.ssh";
$log_file="/tmp/$CName/$YY$MM$DD$HH$mm.log";

#print "$ssh_file \n";
mkdir("/tmp/$CName") if (! -d "/tmp/$CName" );

#Lets initialize the Binpaths of all processes
$Bin_path1{"cae"}="/data/ps_output/CAEBin";
$Bin_path1{"mae"}="/data/ps_output/SEBin/5min/43200";
$Bin_path1{"se"}="/data/ps_output/SEBin/5min/43200";
$Bin_path2{"se"}="/data/ps_output/SEHH/5min";
$Bin_path1{"dme"}="/data/ps_output/DMETrendBin";
$Bin_path1{"qe.Indexer"}="/data/qe/indexes";
$Bin_path1{"re"}="/ndata/routing/EIB";
$Bin_path2{"re"}="/ndata/routing/ASIB";
#lets find out the netflow dir at runtime, since we keep change the nfcapd dumping area.
$Bin_path_dyn{"nr-capture"}="/netflow";
$Bin_path_dyn{"sfcapd"}="/data";
$Bin_path1{"reports.Main"}="/data/rge/output/AutoGenReports/Daily";
$Db_access{"sqlite3"}="/data/ps_output/ps.dbarcaAnom";
#$check_var_logs{"arca"}="/var/log/messages";
$NO_log_check{"qe.thrift"}="yes";
$NO_log_check{"jboss.Main"}="yes";
$NO_log_check{"gnps"}="yes";
$result_check{"CheckDataOnRouter"}="yes";

$dep_check{"arca"}="dme";
$depth=3;
$depth1=5;
$depth2=1;
%checks;

open(FH_Temp,">$ssh_file")||die"could not open $ssh_file";
#open(FH_Log,">$log_file")||die"could not open $log_file";

sub DecodePass
{	
	my $pass=$CPassword;
	my @array=split(//,$pass);
	$CPasswd="";
	foreach(@array)
	{
	
        	$Avalue=ord;
	        $Avalue--;
	        $CPasswd=$CPasswd.chr($Avalue);
	}
	return $CPasswd;
}


sub ReadConfig
{
        open (FH_CONF,"<$ARGV[0]")||die "could not open ConFile";
	while($ConLine=<FH_CONF>)
	{
                chomp $ConLine;
                next if($ConLine=~m/^#/); 
                my @ClientInfo=split(/\s+/, $ConLine);
                if ($ClientInfo[0] eq $CName)
                {
			#$CName=$ClientInfo[0];
			$CHost=$ClientInfo[1];
			$CUser=$ClientInfo[2];
			$CPassword=$ClientInfo[3];
                        $Cinfo_warn=$ClientInfo[4];
                        $Cinfo_crit=$ClientInfo[5];
                        $processes_names=$ClientInfo[6];
                        @processes=split(/,/,$processes_names);
			## If Bin_path_dyn is given alongwith the process name, overwrite the Bin_path_dyn
                        foreach (@processes)
			{
				if ($_ =~ m/(.+):(.+)/)
				{
					$_ = $1;
					$Bin_path_dyn{$_} = $2;
				#	print "$_ => $Bin_path_dyn{$_}\n";
				} 
			}
			$filesystems_names=$ClientInfo[7];
                        @filesystems=split(/,/,$filesystems_names);
                        $file_path{HNAS_access}=$ClientInfo[8];
                        $HNAS_access="" if ( $file_path{HNAS_access} ne "" ); 
		#	print "$CName $CIP $CUser $CPassword \n";
			if (($ClientInfo[0] eq GeantProd) || ($ClientInfo[0] eq GeantTest)) {
                        	$Bin_path1{"se"}="/data/ps_output/SEBin";
                        	$Bin_path2{"se"}="/data/ps_output/SEHH";
			} elsif (($ClientInfo[0] eq TelxAtlanta) || ($ClientInfo[0] eq TelxNY)) {
		                $Bin_path1{"se"}="/data/ps_output/SEBin/15min";
                                $Bin_path2{"se"}="/data/ps_output/SEHH/15min";
                        } else {
                        	$Bin_path1{"se"}="/data/ps_output/SEBin/5min/43200";
                        	$Bin_path2{"se"}="/data/ps_output/SEHH/5min";
                        }
		}

	}
	close(FH_CONF);
}


sub Run_Config
{
	 # Prepare the commands to be executed to get the inforamtion about the process
                   $checks{"cae"}[0]="/opt/tms/bin/cli  -t \"en\" \"internal query iterate subtree /nr/cae/config\" | grep persist_bin";
                   $checks{"cae"}[1]="find `find $Bin_path1{cae}/ -mindepth $depth -maxdepth $depth -type d -mmin -120` -type f -mmin -10 | xargs -i ls -str {} |awk '\$1!=0 { print \$2}' | tail -1";

                   $checks{"se"}[0]="find `find $Bin_path1{se}/ -mindepth $depth -maxdepth $depth  -type d -mmin -90` -type f -mmin -25 | xargs -i ls -str {} |awk '\$1!=0 { print \$2}' | tail -1";

                   $checks{"se"}[1]="find `find $Bin_path2{se}/ -mindepth $depth -maxdepth $depth -type d -mmin -90` -type f -mmin -25 | xargs -i ls -str {} |awk '\$1!=0 { print \$2}' | tail -1";
                   $checks{"mae"}[0]="find `find $Bin_path1{mae}/ -mindepth $depth -maxdepth $depth  -type d -mmin -90` -type f -mmin -30 | xargs -i ls -str {} |awk '\$1!=0 { print \$2}' | tail -1";

                   $checks{"dme"}[0]="find `find $Bin_path1{dme}/ -mindepth $depth -maxdepth $depth -type d -mmin -60` -type f -mmin -10 | xargs -i ls -str {} |awk '\$1!=0 { print \$2}' | tail -1";

                   $checks{"qe.Indexer"}[0]="find `find $Bin_path1{\"qe.Indexer\"}/ -mindepth $depth1 -type d -mmin -60` -type f -mmin -10 | xargs -i ls -str {} |awk '\$1!=0 { print \$2}' | tail -1";

                   $checks{"arca"}[0]="grep \"$dep_check{arca}\.NOTICE\" /var/log/messages | grep \"Anomaly Bin with\" | tail -1";
                   $checks{"arca"}[1]="grep \"arca\.NOTICE\" /var/log/messages | grep \"Anomalies generated\" | tail -1";

                   $checks{"nr-capture"}[0]="find `ps -ef | grep nr-capture |grep -v grep | awk -F \"-l \" '{print \$2}' | awk '{print \$1}'` -maxdepth 1 -type f -mmin -10 | head -5 |xargs -i ls -str {} |awk '\$1!=0 { print \"Netflow: \" \$2}' | tail -1";

                   $checks{"sfcapd"}[0]="find `find $Bin_path_dyn{sfcapd}/ -mindepth 1 -maxdepth 2 -type f -name \"nfcapd.current*\" -mmin -6 | xargs -i dirname {}` -mindepth 4 -maxdepth 4 -type f  -mmin -10 | xargs -i ls -str {} |awk '\$1!=0 { print \$2}' | tail -1";

                   $checks{"reports.Main"}[0]="find $Bin_path1{\"reports.Main\"}/ -mindepth 0 -type f -mmin -3600 | xargs -i ls -str {} |awk '\$1!=0 { print \$2}' | tail -1";
                   $checks{"sqlite3"}[0]="sqlite3 $Db_access{sqlite3} \"select max(id)  from ArcaAnomalies\" | awk  '{print \"db_check:\" \$1 }' ";
                   $checks{"HNAS_access"}="find $file_path{HNAS_access}/`hostname`/ -mindepth $depth2 -maxdepth $depth2 -type f -mmin -5";

                   $checks{"CheckDataOnRouter"}[0]="cat /data/utils/RouterDataResult.txt";

                   $checks{"bgpd"}[0]="cat /data/utils/monitor/bgp_peer.list | grep bgp";
                   $checks{"bgpd"}[1]="cat /data/utils/monitor/bgp_ip.list";
                   $checks{"isis.py"}[0]="cat /data/utils/monitor/isis_peer.list";
                   $checks{"re"}[0]="find $Bin_path1{re}/ -type f -name \"eib*\" -mmin -180 | xargs -i ls -str {} |awk '\$1!=0 { print \$2}' | tail -1";
                   $checks{"re"}[1]="find $Bin_path2{re}/ -type f -name \"asib*\" -mmin -180 | xargs -i ls -str {} |awk '\$1!=0 { print \$2}' | tail -1";
		   $checks{"re_3x"}[0]="o=`ps -eaf |grep \"/opt/tms/bin/re\" | grep -v grep`;if [ -z \"\$o\" ]; then echo \"Re_process: NOT_RUNNING\";else echo \"Re_process: Running Fine\";fi";
                   $checks{"re_3x_bin"}[0]="sdate=`date +%s`;jdate=`hadoop dfs -ls /data/routing/asib/ | grep -v .temp | tail -1 | awk '{print \$6\" \"\$7}'`; j1date=`date --date=\"\$jdate\" +%s`; diff=`expr \$sdate - \$j1date`; if [ \$j1date -ge 9600 ]; then hadoop dfs -ls /data/routing/asib/ | grep -v .temp | tail -1 | awk '{print \$5\" \"\$8}' | awk '\$1!=0 { print \$2}';fi;";
		   $checks{"storage-mount"}[0]="count=`cat /proc/mounts | grep mapper | grep -c \" ro\"`;if [ \$count -eq 1 ]; then echo \"STORAGE_MOUNT:READONLY\";else echo \"STORAGE_MOUNT:READWRITE\";fi";
                   $checks{"UI_login_check"}[0]="egrep \"LoginFailedException:|HTTP POST request from|Validating user\" /data/jboss/jboss_4.0.3sp1/server/default/log/server.log";
                   $checks{"iptables"}[0]="service iptables status | grep \"Firewall is stopped\" ";	
		   $checks{"clusterRole"}[0] = "master=`/opt/tms/bin/cli -t \"en\" \"con t\" \"show cluster master\" | grep \"internal address\" | awk -F, '{print \$1}'| sed 's/Node internal address: //'`; role=\"STANDBY\"; for i in `ifconfig | grep \"inet addr\" | awk '{print \$2}' | awk -F: '{print \$2}'`; do if [ \$master == \$i ]; then role=\"MASTER\"; fi; done; echo \"CLUSTER_ROLE:\"\$role";
                #$checks{"stuckjobs"}[0] = "IFS=\$'\n'; stuck=0; for i in `pmx subshell oozie show workflow RUNNING jobs | grep oozie-admi | awk '{print \$1\"%\"\$10\" \"\$11\"%\"\$13\" \"\$14}'`; do job=`echo \$i | awk -F% '{print \$1}'`; start=`echo \$i | awk -F% '{print \$2}'`; end=`echo \$i | awk -F% '{print \$3}'`; start=`date +%s -d \"\$start\"`; end=`date +%s -d \"\$end\"`; diff=`expr \$end - \$start`; if [ \$diff -gt 7200 ]; then stuck=1; output1=\"STUCK_JOBS: \$job running for more than 2 hrs : \$diff\"; fi; done; if [ \$stuck -eq 0 ]; then output1=\"STUCK_JOBS: No job stuck\"; fi; echo \$output1";
		 $checks{"stuckjobs"}[0]="IFS=\$'\n'; stuck=0; for i in `/opt/tms/bin/pmx subshell oozie show workflow RUNNING jobs | grep oozie-admi | awk '{print \$1\"%\"\$10\" \"\$11\"%\"\$13\" \"\$14}'`; do job=`echo \$i | awk -F% '{print \$1}'`; start=`echo \$i | awk -F% '{print \$2}'`; end=`echo \$i | awk -F% '{print \$3}'`; start=`date +%s -d \"\$start\"`; end=`date +%s -d \"\$end\"`; diff=`expr \$end - \$start`; if [ \$diff -gt 7200 ]; then stuck=1; out+=\"STUCK_JOBS: \$job running for more than 2 hrs : \$diff\"; fi; done; if [ \$stuck -eq 0 ]; then out=\"STUCK_JOBS: No job stuck\"; fi; echo \$out";
                $checks{"failedjobs"}[0]="out=`pmx subshell oozie show workflow FAILED jobs | grep oozie | awk '{print \$2}'| tr '\n' ' '`; echo \"FAILED_JOBS: \$out\"";
                $checks{"rubixExceptions"}[0]="dback=`date -d'now-1 hours' +\"%Y-%m-%d %H:%M\"`; line=`grep -n \"\$dback\" bizreflex.log  |head -1 | awk -F: '{print \$1}'`; out=`tail --lines=+\$line bizreflex.log | grep -i xception`; echo \"RUBIX_EXCEPTIONS:\$out\"";
                $checks{"instadb"}[0]="l=`/opt/tms/bin/cli -t \"en\" \"show run full\" | grep insta | grep cubes-database`;m=`echo \$l | cut -d\" \" -f5`;i=`/usr/local/Calpont/mysql/bin/mysql --defaults-file=/usr/local/Calpont/mysql/my.cnf -u root -e \"use \$m; select maxts from bin_metatable where binclass=\'INSTATIME_60min\' and aggregationinterval=-1;\" | tail -1`; if [ \"\$i\" == \"\" ]; then i=0;fi;j=`date +%s`;k=`expr \$j - \$i`; if [ \$k -gt 21600 ] && [ \$k -le 28800 ]; then out_put=\"INSTA_DATABASE_NOT_UPDATED_IN_PAST_6_HOURS \$i\"; elif [ \$k -gt 28800 ]; then out_put=\"INSTA_DATABASE_NOT_UPDATED_IN_PAST_8_HOURS \$i\"; else out_put=\"DATA_IS_UPDATED_SUCCESSFULLY_IN_INSTA \$i\";fi; echo \$out_put";
		#$checks{"oozie-adi-dir-count"}[0]="count=`ls -l /data/oozie-admi/ | wc -l`; if [ \$count -ge 26000 -a \$count -lt 28000 ];then dir=\"oozie-adi-dir-count-between_26000_and_28000\"; elif [ \$count -ge 28000 ]; then dir=\"oozie-adi-dir-count-greater_than_28000\"; else dir=\"oozie-adi-dir-count-less_than_26000\"; fi; echo \$dir";
	        $checks{"oozie-adi-dir-count"}[0]="count=`ls -l /data/oozie-admi/ | wc -l`; if [ \$count -ge 26000 ]; then dir=\"oozie-adi-dir-count-between_26000_and_28000\"; [ -d /data/oozie-admi/ ] && cd /data/oozie-admi/ && ls -ltr | head -10000 | xargs rm -rf && cd -; else dir=\"oozie-adi-dir-count-less_than_26000\"; fi; echo \$dir";
		$checks{"rubix-FD-count"}[0]="pid=`ps auxw | grep \"/opt/tms/bin/rubixd\" | grep -v grep | awk '{print \$2}'`;count=`ls /proc/\$pid/fd/ | wc -l`;echo \"RUBIX_FD_COUNT:\$count\"";
		#$checks{"hdfs_admin_report"}[0] = "out=`hadoop dfsadmin -report | grep -v WARNING | grep \"Datanodes available:\"`; flag=`echo \$out | grep \"0 dead\" | awk '{print \$1}'`; if [ \$flag ]; then echo \"HDFS_STATUS: RUNNING : \$out\"; else echo \"HDFS_STATUS: \$out\"; fi";
		$checks{"hdfs_admin_report"}[0] = "out=`hadoop dfsadmin -report | grep -v WARNING | grep \"Datanodes available:\"`; echo \"HDFS_STATUS: \$out\";";
		#$checks{"insta_exceptions"}[0] = "exp=`tail -1000 /var/log/messages | grep -i exception | tail -2 | grep -v \"insta_exception:\" | grep -v \"tail \"`; datet=`date \"+%b %d\"`; exp1=`echo \$exp | grep \"\$datet\"`; echo \"insta_exceptions:\$exp1\"";
		$checks{"insta_exceptions"}[0] = "exp=`tail -1000 /var/log/messages | grep -i \"\[insta\.cri\" | grep -iv redirect | grep -iv \"Received a tuple list of size more than\" | tail -2 | grep -v \"insta_exception:\" | grep -v \"tail \"`; datet=`date \"+%b %d\"`; exp1=`echo \$exp | grep \"\$datet\"`; echo \"insta_exceptions:\$exp1\"";
		$checks{"killedjobs"}[0]="IFS=\$'\n'; killed=0; for i in `/opt/tms/bin/pmx subshell oozie show workflow KILLED jobs | grep oozie-admi | awk '{print \$1\"_\"\$2\"%\"\$10\" \"\$11\"%\"\$13\" \"\$14}'`; do job=`echo \$i | awk -F% '{print \$1}'`; sysdate=`date +%s`; end=`echo \$i | awk -F% '{print \$3}'`; killdate=`date +%s -d \"\$end\"`; diff=`expr \$sysdate - \$killdate`; if [ \$diff -lt 14400 ]; then killed=1; out+=\"KILLED_JOBS: \$job killed at: \$end \"; fi; done; if [ \$killed -eq 0 ]; then out=\"KILLED_JOBS: No job killed\"; fi; echo \$out";
		$checks{"bview_copy"}[0]="bv1=`ls -l /data/routing/SPRINT/data/routing/bgp/tables/ | tail -1 | awk '{print \$6\" \"\$7\" \"\$8}'`;bvd=`date --date=\"\$bv1\" +%s`;currd=`date +%s`; diffd=`expr \$currd - \$bvd`; if [ \$diffd -gt 21600 -a \$diffd -lt 28800 ]; then echo BVIEW_NOT_COPIED_PAST_6_HOURS; elif [ \$diffd -gt 28800 ]; then echo BVIEW_NOT_COPIED_PAST_8_HOURS; else echo BVIEW_COPIED_SUCCESSFULLY;fi;";
		$checks{"logdownloader_process"}[0] = "count=`ps -ef | grep logDownloader.sh | grep -v grep | wc -l`; if [ \$count -ne 1 ]; then msg=\"LOGDOWNLOADER_NOT_RUNNING\"; else msg=\"LOGDOWNLOADER_RUNNING_FINE\"; fi; echo \"logdownloader_process:\$msg\"";
		$checks{"logdownloader_log_size"}[0] = "date=`date --date=\"1 days ago\" +\"%Y/%m/%d\"`; hadoop dfs -du /data/sla_logs/downloaded_log/\$date | awk '{ sum+=\$1} END{if(sum==\"\"){print \"logdownloader_log_size:EMPTY\"} else{print \"logdownloader_log_size:\"sum}}'";
		$checks{"postgres"}[0] = "i=`ps auxw | grep -v grep | grep -c postmaster`; if [ \$i -eq 1 ];then j=\"POSTGRES: RUNNING\"; fi; echo \$j";

	  &SSH();
         &ClientData();

}

sub SSH {

	my $timeout=30;
        open(FH_Temp,">$ssh_file")||die"could not open $ssh_file";
        print FH_Temp "start writing \n";
        #my $ssh = Net::SSH::Perl->new("$CHost", debug=>0, identity_files => [ '/home/nagios/.ssh/id_rsa' ]);
        my $ssh = Net::SSH::Perl->new("$CHost", debug=>0);
        &DecodePass();
        $ssh->login("$CUser","$CPasswd");
        print FH_Temp "Connected to host\n";
        print FH_Temp "$CHost $SSHPort $CUser $CPasswd @processes\n";	

	if (defined $processes[0])
                {
                        foreach $process (@processes)
                        {
                        print FH_Temp "IN @processes\n";

			if ( $process eq "apache.catalina" ){($stdout,$stderr,$exit) = $ssh->cmd("ps -eaf |grep $process | grep -v oozie | grep -v grep \n");}
                        if ( $process eq "namenode" ){($stdout,$stderr,$exit) = $ssh->cmd("ps -eaf |grep proc_$process | grep -v grep \n");}
                        if ( $process eq "jobtracker" ){($stdout,$stderr,$exit) = $ssh->cmd("ps -eaf |grep proc_$process | grep -v grep \n");}
                        if ( $process eq "tasktracker" ){($stdout,$stderr,$exit) = $ssh->cmd("ps -eaf |grep proc_$process | grep -v grep \n");}
                        if ( $process eq "datanode" ){($stdout,$stderr,$exit) = $ssh->cmd("ps -eaf |grep proc_$process | grep -v grep \n");}
                        if ( $process eq "collector" ){($stdout,$stderr,$exit) = $ssh->cmd("ps -eaf |grep /platform_latest/collector/bin/collector | grep -v grep \n");}
                        if ( $process eq "insta" ){($stdout,$stderr,$exit) = $ssh->cmd("ps -eaf |grep /platform_latest/insta/bin/insta | grep -v grep \n");}
                        #if ( $process eq "mysqld" ){($stdout,$stderr,$exit) = $ssh->cmd("ps -eaf |grep /usr/local/Calpont/mysql/libexec/mysqld | grep -v grep \n");}
                        else{($stdout,$stderr,$exit) = $ssh->cmd("ps -eaf |grep $process | grep -v grep \n");}

                        print FH_Temp $stdout;
                        #($stdout,$stderr,$exit) = $ssh->cmd("ps -eaf |grep $process | grep -v grep | awk '{print \$2}'  | xargs -i top -b -n 1 -p {} \n");
                        #print FH_Temp $stdout;
                                                if (defined $checks{$process}[0] )
                                                   {
                                                        print FH_Temp $checks{$process}[0]."\n";
                                                     ($stdout,$stderr,$exit) = $ssh->cmd("$checks{$process}[0]  \n");
                                                    	print FH_Temp $stdout;
                                                   }
                                                  if (defined $checks{$process}[1] )
                                                   {
                                                        print FH_Temp $checks{$process}[1]."\n";
                                                    ($stdout,$stderr,$exit) = $ssh->cmd("$checks{$process}[1]  \n");
                                                    print FH_Temp $stdout;
                                                   }
                                                  if (defined $checks{$process}[2] )
                                                   {
                                                        print FH_Temp $checks{$process}[2]."\n";
                                                    ($stdout,$stderr,$exit) = $ssh->cmd("$checks{$process}[2]  \n");
                                                    print FH_Temp $stdout;
                                                   }
                        }
                }

                if (defined $filesystems[0] )
                   {
                        for( $it=0; $it<=$#filesystems; $it++)
                        {
                                ($stdout,$stderr,$exit) = $ssh->cmd("df -Ph $filesystems[$it]\n");
                                print FH_Temp $stdout;
                        }

                   }

                if (defined $HNAS_access )
                   {
                        ($stdout,$stderr,$exit) = $ssh->cmd("$checks{HNAS_access}\n");
                        print FH_Temp $stdout;
                   }

                $ssh->cmd("\n");
                ($stdout,$stderr,$exit) = $ssh->cmd("date --date=now +\"%s\"\n");
                print FH_Temp "date --date=now +\"%s\""."\n";
                print FH_Temp $stdout;
                print FH_Temp "End writing\n";
                close(FH_Temp);

}

sub ClientData
{
        `dos2unix  $ssh_file`;
        $log_validate=`grep "date --date" $ssh_file`;
  #      print "\n\n$log_validate\n\n";
        if ( $log_validate eq "")
        {  print "Not able to connect to client"; exit 2;
        #goto Retry_session
        # &Run_Config; 
        }
        else
        {
         `ln -sf $ssh_file /tmp/$CName/latest_ssh`;
         print "Connection to client is successfull\n";
         exit 0;
        }

  
}

sub main()
{
        #print "In Main\n";
        &ReadConfig;
        &Run_Config;
        #print "Out From Main\n";
}

&main;
