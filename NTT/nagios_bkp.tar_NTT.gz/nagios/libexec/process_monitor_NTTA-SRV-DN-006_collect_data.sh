#!/bin/bash
perl /usr/local/nagios/libexec/AutoSSh_monitor_single.pl /usr/local/nagios/libexec/customerInfo.cfg NTTA-SRV-DN-006
