#!/usr/bin/perl -w

use Expect;
use IO::Pty;
use Switch;
if( (! defined $ARGV[0] ) || (!defined $ARGV[1]) || ( ! defined $ARGV[2] ) || ( $#ARGV < 3 ) ) 
{
	print "Usage: AutoSSh.pl  <ConfigFile> < customer> <[-p <process_name> | -s <filesystem>,<filesystem> | -h <HNASS_access_mount>]>\n";
	exit;
}

$CName=$ARGV[1];
$process=$ARGV[3] if ( $ARGV[2] eq "-p" );
#print $process;
@space=split(/,/, $ARGV[3] ) if ( $ARGV[2] eq "-s" );
$HNAS_acccess=$ARGV[3] if ( $ARGV[2] eq "-h" );
$HNAS_check="" if (defined $HNAS_acccess );
#print $CName, $process;
@time_el=localtime(time);
$YY=$time_el[5]+1900;
$MM=$time_el[4]+1; #$MM="0"."$MM" if ( $MM lt 10);
$DD=$time_el[3];   #$DD="0"."$DD" if ( $DD lt 10);
$HH=$time_el[2];   #$HH="0"."$HH" if ( $HH lt 10);
$mm=$time_el[1];   #$mm="0"."$mm" if ( $mm lt 10);

#$out_file="/tmp/$CName/$YY$MM$DD$HH$mm.out_space" if ( defined @space );
#$out_file="/tmp/$CName/$YY$MM$DD$HH$mm.out_$process" if ( defined $process );
#$ssh_file="/tmp/$CName/$YY$MM$DD$HH$mm.ssh_space" if ( defined @space );
#$ssh_file="/tmp/$CName/$YY$MM$DD$HH$mm.ssh_$process" if ( defined $process );
$ssh_file="/tmp/$CName/latest_ssh";

mkdir("/tmp/$CName") if (! -d "/tmp/$CName" );
#open(FH_DUClient,">$out_file")||die "could not open $out_file";
$cli_check{"cae"}="/nr/cae/config/ae/persist_bin";
$Bin_path1{"cae"}="/data/ps_output/CAEBin";
$Bin_path1{"mae"}="/data/ps_output/SEBin";
$Bin_path1{"se"}="/data/ps_output/SEBin";
$Bin_path2{"se"}="/data/ps_output/SEHH";
$Bin_path1{"dme"}="/data/ps_output/DMETrendBin";
$Bin_path1{"qe.Indexer"}="/data/qe/indexes";
$Bin_path1{"re"}="/ndata/routing/EIB";
$Bin_path2{"re"}="/ndata/routing/ASIB";
$Bin_path3{"re"}="/data/routing/Sprint/merged_ib";
#lets find out the netflow dir at runtime, since we keep change the nfcapd dumping area.
$Bin_path_dyn{"nr-capture"}="/netflow";
$Bin_path_dyn{"sfcapd"}="/data";
#$Bin_path1{"reports.Main"}="/data/rge/output/AutoGenReports/Daily";
$Db_access{"sqlite3"}="/data/ps_output/ps.dbarcaAnom";
$check_var_logs{"arca"}="/var/log/messages";
$NO_log_check{"qe.thrift"}="yes";
$NO_log_check{"jboss.Main"}="yes";
$NO_log_check{"gnps"}="yes";
$dep_check{"arca"}="dme";
$result_check{"CheckDataOnRouter"}="yes";
$check_health{"bgpd"}="yes";
$check_health{"isis.py"}="yes";
$file_path{"HNAS_access"}=$HNAS_acccess;
$login_fail_check{"UI_login_check"}="yes";
$chk_status{"iptables"}="Firewall is stopped";

$depth=3;
$depth=4 if ( ( defined  $process) && ( $process eq "qe.Indexer" ));
sub DecodePass
{
	@array=split(//,$CPassword);
	$CPassword="";
	foreach(@array)
	{
	
        	$Avalue=ord;
	        $Avalue--;
	        $CPassword=$CPassword.chr($Avalue);
	}
}


sub ReadConfig
{
        open (FH_CONF,"<$ARGV[0]")||die "could not open ConFile";
	while($ConLine=<FH_CONF>)
	{
                chomp $ConLine;
                next if($ConLine=~m/^#/); 
                @ClientInfo=split(/\s+/, $ConLine);
                if ($ClientInfo[0] eq $CName)
                {
			@ClientInfo=split(/\s+/,$ConLine);	
			#$CName=$ClientInfo[0];
			$CHost=$ClientInfo[1];
			$CUser=$ClientInfo[2];
			$CPassword=$ClientInfo[3];
                        $Cinfo_warn=$ClientInfo[4];
                        $Cinfo_crit=$ClientInfo[5];
		#	print "$CName $CIP $CUser $CPassword \n";
		}

	}
	close(FH_CONF);
}
sub Run_Config
{
              if (defined $process)
               { 
                  switch ($process)
                  {
                   case "cae" { $check_cmd[0]="find `find $Bin_path1{$process}/ -mindepth $depth -maxdepth $depth -type d -mmin -60` -type f -mmin -10 | xargs -i ls -str {} |awk '\$1!=0 { print \$2}' | tail -1";}
                   case "se"  { $check_cmd[0]="find `find $Bin_path1{$process}/ -mindepth $depth -maxdepth $depth  -type d -mmin -60` -type f -mmin -10 | xargs -i ls -str {} |awk '\$1!=0 { print \$2}' | tail -1";
                               $check_cmd[1]="find `find $Bin_path2{$process}/ -mindepth $depth -maxdepth $depth -type d -mmin -60` -type f -mmin -10 | xargs -i ls -str {} |awk '\$1!=0 { print \$2}' | tail -1"; }
                   case "dme" { $check_cmd[0]="find `find $Bin_path1{$process}/ -mindepth $depth -maxdepth $depth -type d -mmin -60` -type f -mmin -10 | xargs -i ls -str {} |awk '\$1!=0 { print \$2}' | tail -1"; }
                   case "qe.Indexer" { $check_cmd[0]="find `find $Bin_path1{$process}/ -mindepth $depth -type d -mmin -60` -type f -mmin -10 | xargs -i ls -str {} |awk '\$1!=0 { print \$2}' | tail -1"; }
                   case  "arca"      { $check_cmd[0]="grep \"$dep_check{$process}\.NOTICE\" /var/log/messages | grep \"Anomaly Bin with\" | tail -1";
                                       $check_cmd[1]="grep \"$process\.NOTICE\" /var/log/messages | grep \"Anomalies generated\" | tail -1"}
                  
                   case  "nr-capture"  { $check_cmd[0]="find `find $Bin_path_dyn{$process}/ -mindepth 1 -maxdepth 2 -type f -name \"nfcapd.current*\" -mmin -6 | xargs -i dirname {}` -mindepth 3 -type f  -mmin -10 | xargs -i ls -str {} |awk '\$1!=0 { print \$2}' | tail -1"; }
                    case  "sfcapd"  { $check_cmd[0]="find `find $Bin_path_dyn{$process}/ -mindepth 1 -maxdepth 2 -type f -name \"nfcapd.current*\" -mmin -6 | xargs -i dirname {}` -mindepth 3 -type f  -mmin -10 | xargs -i ls -str {} |awk '\$1!=0 { print \$2}' | tail -1"; }
           
                   case "reports.Main" { $check_cmd[0]="find $Bin_path1{$process}/ -mindepth 0 -type f -mmin -3600 | xargs -i ls -str {} |awk '\$1!=0 { print \$2}' | tail -1"; }
                   case  "sqlite3"      { $check_cmd[0]="sqlite3 $Db_access{$process} \"select max(id)  from ArcaAnomalies\" | awk  '{print \"db_check:\" \$1 }' ";} 

                   }
               }
                 
		#	&SSH();
                    
			&ClientData();

}


# This function traps WINCH signals and passes them on
sub winch 
{
		my $signame = shift;
		my $pid = $spawn->pid;
		$shucks++;
 		print "count $shucks,pid $pid, SIG$signame\n";
		$spawn->slave->clone_winsize_from(\*STDIN);
		kill WINCH => $spawn->pid if $spawn->pid;
}	

sub SSH
{
	my $timeout=60;
	open(FH_Temp,">$ssh_file")||die"could not open $ssh_file";
        print FH_Temp "start writing \n";	
	my $spawn = new Expect;
        print FH_Temp "Spawned one\n";
	$spawn->raw_pty(1);
        print FH_Temp "Got pty \n";
	#$spawn->slave->clone_winsize_from(\*STDIN);  # This gets the size of your terminal window
        print FH_Temp "IN window size set\n";
	
	$SIG{WINCH} = \&winch;  # best strategy
        print FH_Temp "Winch sig set\n";
	$Expect::Log_Stdout = 0;
        print FH_Temp "Stdout set \n";
	$spawn=Expect->spawn("ssh $CUser\@$CHost");
        #print ref($spawn);
        $no_attempts=1;
        while ( ref($spawn) ne "Expect")
        { if ( $no_attempts >= 3 ) 
          { print "Not able connect to Client"; $spawn->close(); exit 2; } 
          sleep 10; 
         $spawn=Expect->spawn("ssh $CUser\@$CHost");
         $no_attempts++;
        }
        $spawn->restart_timeout_upon_receive(1);
        print FH_Temp "Connected to host\n";

	#$spawn->log_file("/tmp/autossh.log"); # if you want to see all logs
	&DecodePass();
#       print "$CName $CIP $CUser $CPassword \n";

	my $ret = $spawn->expect
       
       ($timeout,
                [ qr/password: /i, sub { my $spawn = shift;$spawn->send("$CPassword\n"); exp_continue; } ],
               # [ qr/\w+\s+>/           => sub { $spawn->send("en\r_shell\r"); exp_continue; } ],
                [ qr/\w+\s+>/           => sub { $spawn->send("en\n"); $spawn->send(" "); $spawn->send("_shell\n"); exp_continue; } ],
#                [ qr/\w+\s+#/           =>  sub { $spawn->send("_shell\r"); exp_continue; } ],
                [ qr/\w+\s+#/           => sub { if (defined $process )
                                                 { 
                                                  $spawn->send("ps -eaf |grep $process | grep -v grep \n"); 
                                                   $spawn->send("ps -eaf |grep $process | grep -v grep | awk '{print \$2}'  | xargs -i top -b -n 1 -p {} \n");
                                                  if (defined @check_cmd )
                                                   {  for( $it=0; $it<=$#check_cmd; $it++)
                                                     {
                                                       # print $check_cmd[$it];
                                                      $spawn->send("$check_cmd[$it]  \n");
                                                     } 
                                                   } 
                                                 }
                                                 if ( defined $space[0] )
                                                 { for( $it=0; $it<=$#space; $it++)  { $spawn->send("df -h $space[$it]\n");}
                                                 }
                                                 $spawn->send("date --date=now +\"%s\"\r");
                                                 exp_continue } ],
                [ qr/\w+\s+#/           => sub { $spawn->send("exit\r"); exp_continue; } ],
        );

	my $output = $spawn->before();
	print FH_Temp $output;
        print FH_Temp "End writing\n";
	close(FH_Temp);
        #$spawn->soft_close();
         $spawn->close();
}

sub ClientData
{

	open(FH_Temp,"<$ssh_file")||die"could not open temp $ssh_file";
	while($lines=<FH_Temp>)
	{   chomp($lines);
            $sys_time=$1 if ($lines=~m/^(\d+)$/);  	
            #print $sys_time; 
            if (defined $process ) 
            {  if($lines=~m/(\d+) admin /)
		{
                   @line=split(/\s+/, $lines);	
                  if ( $line[$#line] eq $process ) 
                  { $p_id{$process}=$1;
                    $cpu_info{$process}="$line[$#line - 3]";
                    $mem_info{$process}="$line[$#line - 2]"; 
                #  print $p_id{$process},$cpu_info{$process},$mem_info{$process};
                  }   
             #      print FH_DUClient $lines; 
		}	
             }
            if (defined $space[0] )
#            { if($lines=~m/%\s+\/\w+$/)

	    { 
		if( $lines=~m/^\/dev/ || $lines=~m/^[0-9.]+:\// ) 
                {
                my @line=split(/\s+/, $lines);
                $line[$#line - 1]=~s/%//;
                $space_check{$line[$#line]}=$line[$#line  - 1]; 
                #print $result{$line[$#line]};
                #print FH_DUClient "\n $lines \n";
                }
            }
	}	
	close(FH_Temp);

if ( defined $process )
{ 
     $success_proc=0;
   if ( ! defined $p_id{$process} )
    {
    # This check is for qe/jboss like processes which does java on top command output
      if ( "$process" eq "se" )
      { $process_grepp=`grep "$process "  $ssh_file | grep "admin "`;}
      else 
      {$process_grepp=`grep $process $ssh_file | grep "admin "`;}  
    	
	chomp($process_grepp);
    	$process_grepp=~m/admin\s+(\d+)\s+/; 
    	#$process_grep=$';
    	#print $process_grep; 
    	$p_id{$process}=$1;
    	$process_top=`grep "$p_id{$process} admin "  $ssh_file`;
    	@process_top_array=split(/\s+/, $process_top);
    	$cpu_info{$process}="$process_top_array[$#process_top_array - 3]";
    	$mem_info{$process}="$process_top_array[$#process_top_array - 2]";
    
        # We have double checked the process existance from ps and top commands combinations.
	# now decide the PID of the process is available or not

	if (! defined $p_id{$process})
    	{ $success_proc++; $failure{$process}="NOT_RUNNING"; }
    }


	#Lets send the comment for the process as its running/not_running to the caller of this script.

	$comment{$process}="$process is running fine" if ( $p_id{$process} ne "");

   	#Checking the binaray output files of relevent processses. 
        
        #Check the cli config before checking the bins
        $cli_check_status{$process}=`grep "^$cli_check{$process}" $ssh_file | awk '{print \$3}'` if (defined $cli_check{$process});
        #print "cli check status is $cli_check_status{$process}";
        chomp($cli_check_status{$process});
        
        if( ( ! defined $cli_check{$process} ) || ( $cli_check_status{$process} eq "true" ) )
         {
          $Bin_check=`grep "^$Bin_path1{$process}" $ssh_file` if (defined $Bin_path1{$process});
         }
	
        $Bin_check=`grep "^Netflow:"  $ssh_file| grep "nfcapd.current"` if (defined $Bin_path_dyn{$process});
	$Db_out=`grep "^db_check" $ssh_file| awk -F ":" '{print \$2}'` if (defined  $Db_access{$process} ); 
	#print $Bin_check;
        #Now we need to check for the second level/type of bins
 
	if ( ( defined $Bin_path2{$process} ) && ( defined $Bin_check ) )
	{ undef $Bin_check; $Bin_check=`grep "^$Bin_path2{$process}" $ssh_file`; } 

	#   print "bin $Bin_check"; print $p_id{$process};

        #Let send the comment for the process 
	if ( ($Bin_check eq "") && ( $p_id{$process} ne "" ) && ( ( defined $Bin_path1{$process}) || (defined $Bin_path_dyn{$process}) ) && ( defined $Bin_check) ) 
	{ $success_proc++;
	$failure{$process}=" RUNNING_but_no_bins_found";} 
	
	if ( ( defined $check_var_logs{$process} ) && ( $p_id{$process} ne "" ) )
	{
	$log_time_dep=`grep "$dep_check{$process}\.NOTICE"  $ssh_file | awk -F "= " '{print \$2}'`; 
	$log_time_last=`grep "$process\.NOTICE"  $ssh_file | awk -F "TS:" '{print \$2}'`; $diff_time=($log_time_dep - $log_time_last);

	#    print $log_time_dep; print $log_time_last;
	    if ( $diff_time > 3600 )
   	     {
	      $failure{$process}="RUNNING_but_var_log_check_fail_to_sync with $dep_check{$process}"; $success_proc++; }
        }
 
        if ( ( defined  $Db_access{$process}  ) &&  ( defined $Db_out ) )
  	 { $success_proc=0; $comment{$process}="$process is working fine";} 

   switch ($process)
    {
       case "cae"  { if ( $cli_check_status{$process} eq "true" )
                     { 
                      @split_bin=split(/\//,$Bin_check); $last_bin=$split_bin[$#split_bin]; $last_bin=~s/\.ae//;  #print $last_bin; print $sys_time;
                      $diff_live=($sys_time - $last_bin);  $diff_live_min=($diff_live/60);
                      $comment{$process}="$process is running fine in replay-mode  with  $diff_live_min min difference(bins persist ON)" if ( $diff_live > 900 );
                      #print $diff_live;
                      $comment{$process}="$process is running fine in live-mode(bins persist ON)" if ( $diff_live < 900 );
                     }
		     else
		      {
			$comment{$process}="$process is running fine (bins persist OFF)" if ( $success_proc == 0);
			
		      }
                   }
        case "se"   { @split_bin=split(/\//,$Bin_check); $last_bin=$split_bin[$#split_bin]; $last_bin=~s/\.hh//;
                  $diff_live=($sys_time - $last_bin); $diff_live_min=($diff_live/60);
                   #$comment{$process}="$process is running fine in replay-mode  with  $diff_live_min min difference" if ( $diff_live > 1200 );
                   #$comment{$process}=" $process is running fine in live-mode" if ( $diff_live < 1200 );
                     }
	case "instadb"  {
                        $out = `grep "^INSTA_DATABASE_NOT_UPDATED_IN_PAST_6_HOURS" $ssh_file`;chomp $out;
                        @out_t = split(" ",$out);
                        $out_tt=$out_t[1];
                        $out_time = scalar(localtime($out_tt));

                        $out1 = `grep "^DATA_IS_UPDATED_SUCCESSFULLY_IN_INSTA" $ssh_file`;chomp $out1;
                        @out1_t = split(" ",$out1);
                        $out1_tt=$out1_t[1];
                        $out1_time = scalar(localtime($out1_tt));

                        $out2 = `grep "^INSTA_DATABASE_NOT_UPDATED_IN_PAST_8_HOURS" $ssh_file`;chomp $out2;
                        @out2_t = split(" ",$out2);
                        $out2_tt=$out2_t[1];
                        $out2_time = scalar(localtime($out2_tt));
                        $curr_time = localtime;
                        if($out ne "" && $out =~ m"INSTA_DATABASE_NOT_UPDATED_IN_PAST_6_HOURS")
                                {
                                $failure{$process} = "data is not updated in INSTA in past 6 hours, INSTA_LAST_UPDATE_TIME: $out_time, SYSTEM_CURRENT_TIME: $curr_time"; $success_proc=1;
                                }
                        if($out2 ne "" && $out2 =~ m"INSTA_DATABASE_NOT_UPDATED_IN_PAST_8_HOURS")
                                {
                                $failure{$process} = "data is not updated in INSTA in past 8 hours, INSTA_LAST_UPDATE_TIME: $out2_time, SYSTEM_CURRENT_TIME: $curr_time"; $success_proc=2;
                                }
                        elsif($out1 ne "" && $out1 =~ m"DATA_IS_UPDATED_SUCCESSFULLY_IN_INSTA")
                                {
                                $comment{$process} = "data is updating properly in insta, INSTA_LAST_UPDATE_TIME: $out1_time, SYSTEM_CURRENT_TIME: $curr_time"; $success_proc = 0;
                                }
                        }
	case "stuckjobs" {
                        $out = `grep "^STUCK_JOBS:" $ssh_file`;
                        chomp $out;
                        if ( $out =~ m/No job stuck/ )
                          { $comment{$process}="No job stuck"; $success_proc=0; }
                         else
                          { $success_proc++; $failure{$process}="$out"; }
                        }
	case "killedjobs" {
                        $out = `grep "^KILLED_JOBS:" $ssh_file`;
                        chomp $out;
                        ($out1,$tmp) = split /:/, $out, 2;
                        if ( $tmp =~ m/No job killed/ )
                          { $comment{$process}="No job killed"; $success_proc=0; }
                         else
                          { $success_proc++; $failure{$process}="$tmp"; }
                        }
        case "failedjobs" {
                        $out = `grep "^FAILED_JOBS:" $ssh_file`;
                        chomp $out;
                        $out =~ s/FAILED_JOBS:\s*//;
                        if ( $out =~ m/^\s*$/ )
                          { $comment{$process}="No job failed"; $success_proc=0; }
                         else
                          { $success_proc++; $failure{$process}="failed_jobs : $out"; }
                        }
        case "rubixExceptions" {
                        $out = `grep "^RUBIX_EXCEPTIONS:" $ssh_file`;
                        chomp $out;
                        $out =~ s/RUBIX_EXCEPTIONS:\s*//;
                        if ( $out =~ m/^\s*$/ )
                          { $comment{$process}="No exceptions found"; $success_proc=0; }
                         else
                          { $success_proc++; $failure{$process}="exceptions : $out"; }
                        }
	case "clusterRole"  {
                        $out = `grep "^CLUSTER_ROLE:" $ssh_file`;
                        chomp $out;
                        $out =~ s/CLUSTER_ROLE://; $out =~ s/\%//;
                         $success_proc = 0; $comment{$process}="is $out";
                        }
	case "oozie-adi-dir-count" {
                                $dir = `grep "^oozie-adi-dir-count" $ssh_file`;chomp $out;
                                if($dir =~ m"^oozie-adi-dir-count-between_26000_and_28000")
                                        {
                                        $failure{$process} = "/data/oozie-adi/ directory count is between 26000 and 28000";$success_proc=1;
                                        }
                                elsif($dir =~ m"^oozie-adi-dir-count-greater_than_28000")
                                        {
                                        $failure{$process} = "/data/oozie-adi/ directory count is greater than 28000";$success_proc=2;
                                        }
                                elsif($dir =~ m"^oozie-adi-dir-count-less_than_26000")
                                        {
                                        $comment{$process} = "/data/oozie-adi/ directory count is less than 26000";$success_proc = 0;
                                        }
                                  }
	case "rubix-FD-count" {
                                $out = `grep "^RUBIX_FD_COUNT" $ssh_file`;chomp $out;
                                my ($tmp,$exp) = split /:/, $out, 2;
                                if(defined $exp and $exp !~ m/^\s*$/) { $success_proc=0; $comment{$process}= $tmp . ":" . $exp; }
                                else { $success_proc++; $failure{$process}="File Descriptor not found"; }
                                }
	case "re_3x"  {
				$out = `grep "^Re_process:" $ssh_file`;chomp $out;
				my ($tmp,$exp) = split /:/, $out, 2;
				if( $exp =~ m/Running Fine/) { $success_proc=0; $comment{$process}="re is running fine";}
				else { $success_proc++; $failure{$process}="re" . $exp;};
			}
	case "re_3x_bin" {
				$out = `grep "^/data/routing/asib/" $ssh_file`;chomp $out;
				if( $out ne "" ) 
					{
					$comment{$process} = "Bins found";$success_proc = 0;
					}
				else
					{
					$failure{$process} = "No_bins_found";$success_proc=1;
					}
		   }
	case "hdfs_admin_report"
                        { $out = `grep "^HDFS_STATUS: Datanodes" $ssh_file`;
			  my ($tmp,$exp) = split /,/, $out, 2;
			  $exp =~ s/^\s//g;
			  @out1 = split(/ /,$exp);
                          if( $out1[0] > 0 && $out1[0] < 2) 
				{ 
				$success_proc=1;
                                $failure{$process}="$out";
				}
                          elsif( $out1[0] > 1 )
				{
				$success_proc=2;
                                $failure{$process}="$out,  More than 1 datanodes are dead";
				}
			else
				{ 
				$success_proc=0;
                                $comment{$process}="$process: $out";
				}
                        }
	case "insta_exceptions"
                        { $out = `grep "^insta_exceptions:" $ssh_file`;
                                chomp $out;
                                my ($tmp,$exp) = split /:/, $out, 2;
                                if(defined $exp and $exp !~ m/^\s*$/) { $success_proc++; $failure{$process}=$exp; }
                                else { $success_proc=0; $comment{$process}="No exceptions found"; }
                        }
	case "storage-mount"
                        { $out = `grep "^STORAGE_MOUNT" $ssh_file`;
                                chomp $out;
                                my ($tmp,$exp) = split /:/, $out, 2;
                                if($exp =~ m/READONLY/) { $success_proc++; $failure{$process}="storage mounted in read only mode"; }
                                elsif($exp =~ m/READWRITE/) { $success_proc=0; $comment{$process}="storage mounted in read write mode"; }
                        }
	case "bview_copy" {
                                $dir = `grep "^BVIEW_" $ssh_file`;chomp $out;
                                if($dir =~ m"^BVIEW_NOT_COPIED_PAST_6_HOURS")
                                        {
                                        $failure{$process} = "bview file not copied from past 6 hours in /data/routing/SPRINT/data/routing/bgp/tables/";$success_proc=1;
                                        }
                                elsif($dir =~ m"^BVIEW_NOT_COPIED_PAST_8_HOURS")
                                        {
                                        $failure{$process} = "bview file not copied from past 8 hours in /data/routing/SPRINT/data/routing/bgp/tables/";$success_proc=2;
                                        }
                                elsif($dir =~ m"^BVIEW_COPIED_SUCCESSFULLY")
                                        {
                                        $comment{$process} = "bview file copied successfully in /data/routing/SPRINT/data/routing/bgp/tables/ directory";$success_proc = 0;
                                        }
                           }
	case "logdownloader_process"
                        { $out = `grep "^logdownloader_process:" $ssh_file`;
                                if($out =~ m/LOGDOWNLOADER_RUNNING_FINE/) { $success_proc=0; $comment{$process}="$process is running fine"; }
                                else { $success_proc++; $failure{$process}="Logdownloader is not running"; }
                        }
	case "logdownloader_log_size"
                        { $out = `grep "^logdownloader_log_size" $ssh_file`;
                                my ($tmp,$size) = split /:/, $out, 2;
                                if(defined $size) { $success_proc=0; $comment{$process}=$size; }
                                elsif($size =~ m/EMPTY/){$success_proc++; $failure{$process}="Size not found";}
                                else { $success_proc++; $failure{$process}="Size not found"; }
                        }
	case "postgres"  {
                        $out = `grep "^POSTGRES:" $ssh_file`;
                        chomp $out;
                        $out =~ s/POSTGRES://; $out =~ s/\%//;
                         $success_proc = 0; $comment{$process}="is $out";
                        }



    }

    # Lets check the data on CheckdataonRouter process to display
     if( $result_check{$process} )
      { $success_proc=0; 
      
       $result_text=`grep -E  "PASS|FAIL|NEW" $ssh_file`;
       #print $result_text;
       $result_text=~s/\n/ ,/g;
       $result_text=~s/,$//; 
       if ( $result_text eq "" )
       {
       $comment{$process}="CheckDataOnRouter has PASS on all routers";
       }
       else 
       {
       $success_proc++;
       $failure{$process}=$result_text;
       }
      }
 
    # Validate the bgp and isis peering  based on the tcpdump output from RE node
    if ( ( defined $check_health{$process}) && ( $p_id{$process} ne "" ) )
     { 
       switch ($process)
       {
         case "bgpd"  { @bgp_peers=`grep "\.bgp\$" $ssh_file | grep -E "^[0-9]" | sed -e s/\.bgp\$//g`;
                        @bgp_ips=`grep "^IP:" $ssh_file | sed -e s/IP://g`;
                        @missing_peers;
                        foreach(@bgp_ips)
                         {  chomp;
                            my $tmp=$_;
                            if ( ! grep(/$tmp/, @bgp_peers) )
                             {
                              push(@missing_peers, $tmp); 
                             }
                           
                          }
                         if ( $#missing_peers > 0 )
                          { $success_proc++; $failure{$process}=" is running but missing peering with @missing_peers"; }
                          else
                          {  $comment{$process}="$process  is running with all peerings UP"; }
                       }

        case "isis.py" { $isis_check=`grep IS-IS $ssh_file | grep LSP | grep L1`;
                         if ( $isis_check ne "" )
                          { $comment{$process}="$process  is running with peering UP "; }
                         else
                          { $success_proc++; $failure{$process}=" is running but  missing peering ACK"; }
                       }
       }

     }
	if( "$login_fail_check{$process}" eq "yes" )
	{
	@login_list=`cat $ssh_file | egrep "LoginFailedException|HTTP|Validating" | grep ^[0-9]`;
        
        $login_fail=0;@logins;
        	for(my $it=0; $it<scalar(@login_list); $it++)
		{ chomp $login_list[$it];
		  if ( $login_list[$it] =~/HTTP POST request from client/ )
		   {
                     $login_ip=`echo "$login_list[$it]" | awk -F ": " '{print \$NF}'`;
                     chomp($login_ip);
		     $login_time=`echo "$login_list[$it]" | awk -F "," '{print \$1}'`;
		     $login_time=~s/^\d+://g; 
		     chomp $login_time;
		     $login_time_utc=`echo $login_time | xargs -i date +%s -d '{}'`;
		     chomp($login_time_utc);
                     # print "$sys_time $login_time_utc\n";
                   }
		  if ( $login_list[$it] =~/Validating user/ )
		   {
		     $user=`echo "$login_list[$it]" | awk -F ": " '{print \$NF}'`;
		     chomp $user;
		     $login_ip="$login_ip".":$user";
		     $login_detail="$login_time_utc".":$login_ip";
		     if ( ($sys_time - $login_time_utc) < 900 )
                      {
		       push(@logins,$login_detail); 
		      }
		     #print "$login_ip\n";
		     
 		   }
		  if ( $login_list[$it] =~/LoginFailedException/ )
		   {
 		     if ( ($sys_time - $login_time_utc) < 900 )
                      {
                       $login_fails{$login_ip}++;
                       $login_fail++;
		      }
                   } 
		}
	 $failure{$process}="";
         #print %login_fails;
         while( ($ip,$ite)=each(%login_fails) )
 	  {
	   $failure{$process}="$failure{$process}"." from host $ip $ite times"; 
          } 
	 $failure{$process}="UI login failure "."$failure{$process}" if ( $failure{$process} ne "");
		if ( $failure{$process} ne "")
		{ 
		 $success_proc++;
		}
		else
		{
		$success_proc=0;
	         if ( scalar(@logins) == 0 )
		 {	$comment{$process}="$process : NO failures reported\n";
		   
		 }
		 else{$\="\t"; $comment{$process}="Logins  @logins\n";}
		}
	#print $failure{$process};
	}	

	if ( defined $chk_status{"$process"} )
	{ 
	  
	  $chk_st=`grep "^$chk_status{$process}" $ssh_file`;
	  chomp($chk_st);
	  
	   if ( $chk_st eq "")
	   {
		$success_proc=0;
		$comment{$process}="$process is running fine";	    
	   }
	
	}
	
	  #close(FH_DUClient);
	 if($success_proc eq 0)
	  {
	   # print "$process"; 
	   print " $comment{$process}";
	   exit 0;
	  }
	 else
	   {
	   print "$process : $failure{$process}"; 
	   exit 2 if ( $failure{$process} eq "NOT_RUNNING");
	   exit 2 if ( $failure{$process} =~ m"data is not updated in INSTA in past 8 hours");
	   exit 2 if ( $failure{$process} =~ m"directory count is greater than 28000");
	   exit 2 if ( $failure{$process} =~ m"More than 1 datanodes are dead");
	   exit 2 if ( $failure{$process} =~ m"bview file not copied from past 8 hours");
	   exit 1;
	   }
}  


 #Now we are checking the space utilization on different filesystem partitions.
  if (defined $space[0] )
   {
  	$success_space=0; 
  	foreach $fdisk (@space)
  	{ 
#	if( ! defined $space_check{$fdisk} )
#   	  { $success_space=1; $fail{$fdisk}="NOT existing";}
   	 if ( $space_check{$fdisk} >= $Cinfo_warn )
   	  { $success_warn=2; $fail_warn{$fdisk}="partition $fdisk used  $space_check{$fdisk} % "; }
    
   	 if ( $space_check{$fdisk} >= $Cinfo_crit )
    	  { $success_crit=3; $fail_crit{$fdisk}="partition $fdisk used $space_check{$fdisk} % ";}
  
    }  
    if ( $success_space  eq 0 ) 
    { 
     if ( defined $success_crit ) { $,="\t";  print  values( %fail_crit) ; exit 2; }
     if ( defined $success_warn ) { $,="\t";  print  values( %fail_warn) ; exit 1; }
     while(($k,$v)=each(%space_check)) 
     { print "partition $k $v % used  "; } 
     exit 0;
    }
    else { $,="\t";  print keys( %fail); print  values( %fail); exit 2; }    
  }


  if ( defined $HNAS_check )
  {
    $success_hnas=0;
    
    $check_result=`grep "^$file_path{HNAS_access}" $ssh_file`;
    if  ( $check_result )
    {  
     print "HNAS is writable from host $CName"; 
     exit 0;
    }
    else
    {
     print "HNAS is not accessible to wirte/read from host $CName";
     exit 1;
    }
  }


}

sub SendMail()
{
	`mutt -s \"DiskUsageInfo\" anji\.gorantla\@guavus\.com \< DiskUsage\.txt`;

}

sub main()
{
	#print "In Main\n";
	&ReadConfig;
        &Run_Config;
#	&SendMail;
	#print "Out From Main\n";
}

&main;

Retry_session:
#retrying to make  session 
&Run_Config;


