#!/bin/bash
perl /usr/local/nagios/libexec/AutoSSh_monitor_check.pl /usr/local/nagios/libexec/customerInfo.cfg   NTTA-SRV-DN-003  -s /,/var,/data,/data/hadoop-admin
