#!/bin/bash
perl /usr/local/nagios/libexec/AutoSSh_monitor_check.pl /usr/local/nagios/libexec/customerInfo.cfg NTTA-SRV-INSTA-001 -s /,/data,/var,/guavus/insta,/data/Calpont/data1,/data/Calpont/data2,/data/Calpont/data3,/data/Calpont/data4
