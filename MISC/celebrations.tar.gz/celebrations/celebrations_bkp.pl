#!/usr/bin/perl
#use strict;
use CGI qw(:cgi);
use CGI::Carp qw(fatalsToBrowser);
use Mail::Sendmail;
use POSIX qw(strftime);
#use Spreadsheet::XLSX;
use MIME::Lite;


$day = strftime "%d", localtime;
$mon = strftime "%b", localtime;
$yr = strftime "%y", localtime;
$past_date=$ARGV[0];

chomp($past_date);

#$bcc='gurgaon@guavus.com,abad@guavus.com';
$bcc='gaurav.babbar@guavus.com';

$run_date=`date`;
chomp($run_date);


if (! $past_date){

#open (OUT,">>/data/TOOLS_TEAM/root/celebration/out.log") || die $!;
open (OUT,">>out.log") || die $!;
open (IN,"test.csv") || die $! ;
#my $worksheet = $parser->worksheet('Sheet1');

#foreach my $sheet ( @{ $parser->{Worksheet} } ) {
	
#	foreach my $row ( 1 .. $sheet->{MaxRow} ) {
while ($line=<IN>){
		chomp($line);	

		@temp=split(/,/,$line);
		#$name = $sheet->{Cells}[$row][2]{Val};
		#$sr_name = $sheet->{Cells}[$row][3]{Val};
        	#$email = $sheet->{Cells}[$row][8]{Val};
            #$email='gaurav.babbar@guavus.com';
		$name=$temp[0];
		chomp($name);
		$email=$temp[1];
		chomp($email);
        	#$doj = $sheet->{Cells}[$row][6]{Val};
        	#$dob = $sheet->{Cells}[$row][5]{Val};
		$dob=$temp[3];
		$doj=$temp[2];
		@a1=split(/-/,$dob);
		@a2=split(/-/,$doj);

		$doj_date=$a2[0];
		$doj_mnth=$a2[1];
		$doj_yr=$a2[2];

		$dob_date=$a1[0];
		$dob_mnth=$a1[1];

		if (($name) && ($email) && ($doj) && ($dob)) {
		

			if (($dob_date == $day) && ($dob_mnth eq $mon)){	
				#my $msg = "";
				print OUT "$run_date Happy Bday : matched DOB $email1 $name $dob_date $dob_mnth in dob match\n";

		my $msg = MIME::Lite->new(
                 	To      =>"$email",
                 	#To      =>"gaurav.babbar@guavus.com",
			Bcc => "$bcc",
                 	#from =>'CELEBRATIONS@guavus.com',
                 	from =>'celebration.mail@guavus.com',
                 	Subject =>"TEST MAIL",
                 	Disposition =>'inline',
                 	Type    =>'multipart/related'
                 	);
    
    	$msg->attach(Type => 'text/html',
                 Data => qq{ <body> This is a test mail, Please ignore..</body>}
                 );

	$msg->send;
	#$msg->send("smtp", "outlook.office365.com", AuthUser=>'celebration.mail@guavus.com',AuthPass=>'C3l3br@t!0n.m@!l',Debug=>1);
	#$msg->send("smtp", "outlook.office365.com");
			
				}

			
            

        }

}

close(OUT);
close(IN);
}
