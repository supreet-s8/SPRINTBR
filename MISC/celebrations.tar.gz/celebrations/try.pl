#!/usr/bin/perl
#use strict;
use CGI qw(:cgi);
use CGI::Carp qw(fatalsToBrowser);
use Mail::Sendmail;
use POSIX qw(strftime);
#use Spreadsheet::XLSX;
use MIME::Lite;


$day = strftime "%d", localtime;
$mon = strftime "%b", localtime;
$yr = strftime "%y", localtime;
$past_date=$ARGV[0];

chomp($past_date);

#$bcc='gurgaon@guavus.com,abad@guavus.com';
$bcc='gaurav.babbar@guavus.com';

$run_date=`date`;
chomp($run_date);

if (! $past_date){

#open (OUT,">>/data/TOOLS_TEAM/root/celebration/out.log") || die $!;
open (OUT,">>out.log") || die $!;
open (IN,"test.csv") || die $! ;
#my $worksheet = $parser->worksheet('Sheet1');

#foreach my $sheet ( @{ $parser->{Worksheet} } ) {
	
#	foreach my $row ( 1 .. $sheet->{MaxRow} ) {
while ($line=<IN>){
		chomp($line);	

		@temp=split(/,/,$line);
		$name=$temp[0];
		chomp($name);
		$email=$temp[1];
		chomp($email);
		$dob=$temp[3];
		$doj=$temp[2];
		@a1=split(/-/,$dob);
		@a2=split(/-/,$doj);

		$doj_date=$a2[0];
		$doj_mnth=$a2[1];
		$doj_yr=$a2[2];

		$dob_date=$a1[0];
		$dob_mnth=$a1[1];

		if (($name) && ($email) && ($doj) && ($dob)) {
		

			if (($dob_date == $day) && ($dob_mnth eq $mon)){	
				#my $msg = "";
				print OUT "$run_date Happy Bday : matched DOB $email1 $name $dob_date $dob_mnth in dob match\n";

open(FILE, ">file.html") or die "Cannot open $file: $!";
print FILE "<HTML>\n";
print FILE "<body bgcolor=\"white\"><FONT FACE=\"apple chancery\" FONT SIZE=\"5\" FONT COLOR=\"IndianRed\">\n"; 
print FILE "<b>Dear $name,<br><br>Guavus wishes for you all that you hope for, all that you dream of, all that makes you happy on this very special day.<br>May this day be filled with sunshine, smile, laughter and love...<br><br>A very Happy Birthday !!<br>\n"; 
print FILE "<br>Cheers<br>HR India</b></body></FONT></HTML>\n";
print FILE "<img src=\"cid:tickjpeg\" /><br>\n";
print FILE "Content-Type: image/jpeg\n";
print FILE "Content-Transfer-Encoding: base64\n";
print FILE "Content-Id: <tickjpeg>\n";
close(FILE);

				}
	}

}
}
