#!/usr/bin/perl


$in_file=$ARGV[0];

open(IN,"$in_file") || die "$!\n";

#open(OUT,">>","/data/celebrations/list.csv") || die "$!\n";

@array=<IN>;
#$flag=0;
foreach $i (0..$#array){


    if (($array[$i]=~/^dn:/) && ($array[$i] !~ /Contractors/)){
        while($array[$i] !~ /^$/){

            if ($array[$i] =~ /displayName/){
            my @temp=split(/:/,$array[$i]);
            #print "$mo[$#mo]\n";  
            $name=$temp[1];
            chomp($name);
            $name =~ s/^\s//g;
            }

            if ($array[$i] =~ /mail/){
            my @temp=split(/:/,$array[$i]);
            $mail=$temp[1];
            chomp($mail);
            $mail=~ s/^\s//g;
            }  

            if ($array[$i] =~ /extensionAttribute11/){

            my @temp=split(/:/,$array[$i]);
            $jd=$temp[1];
            chomp($jd);
            $jd=~ s/^\s//g;
            }

            if ($array[$i] =~ /extensionAttribute10/){

            my @temp=split(/:/,$array[$i]);
            $bday=$temp[1];
            chomp($bday);
            $bday=~ s/^\s//g;
            }
            $i++;
        }
    print  "$name,$mail,$jd,$bday\n";
    next;
    }

}
close (IN);
#close (OUT);
