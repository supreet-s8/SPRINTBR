#!/usr/bin/perl
#use strict;
use CGI qw(:cgi);
use CGI::Carp qw(fatalsToBrowser);
use Mail::Sendmail;
use POSIX qw(strftime);
#use Spreadsheet::XLSX;
use MIME::Lite;


$day = strftime "%d", localtime;
$mon = strftime "%b", localtime;
$yr = strftime "%y", localtime;
$past_date=$ARGV[0];

chomp($past_date);

#$bcc='gurgaon@guavus.com,abad@guavus.com';
#$bcc='gaurav.babbar@guavus.com';

$run_date=`date`;
chomp($run_date);


if (! $past_date){

open (OUT,">>/data/celebrations/out.log") || die $!;
#open (IN,"/data/celebrations/list.csv") || die $! ;
open (IN,"/data/celebrations/test.csv") || die $! ;

while ($line=<IN>){
		chomp($line);	

		@temp=split(/,/,$line);
		#$name = $sheet->{Cells}[$row][2]{Val};
		#$sr_name = $sheet->{Cells}[$row][3]{Val};
        	#$email = $sheet->{Cells}[$row][8]{Val};
            #$email='gaurav.babbar@guavus.com';
		$name=$temp[0];
		chomp($name);
		$email=$temp[1];
		chomp($email);
        	#$doj = $sheet->{Cells}[$row][6]{Val};
        	#$dob = $sheet->{Cells}[$row][5]{Val};
		$dob=$temp[3];
		$doj=$temp[2];
		@a1=split(/-/,$dob);
		@a2=split(/-/,$doj);

		$doj_date=$a2[0];
		$doj_mnth=$a2[1];
		$doj_yr=$a2[2];

		$dob_date=$a1[0];
		$dob_mnth=$a1[1];

		if (($name) && ($email) && ($doj) && ($dob)) {
		
			
			if (($dob_date == $day) && ($dob_mnth eq $mon)){	
				#my $msg = "";
				print OUT "$run_date Happy Bday : matched DOB $email1 $name $dob_date $dob_mnth in dob match\n";
			$pik=$name;
			$pik=~ s/\s/_/g;

		my $msg = MIME::Lite->new(
                 	To      =>"gaurav.babbar\@guavus.com",
			#Bcc => "$bcc",
                 	#from =>'CELEBRATIONS@guavus.com',
                 	from =>'celebration.mail@guavus.com',
                 	Subject =>"Happy Birthday $name  : $day-$mon !!!!",
                 	Disposition =>'inline',
                 	Type    =>'multipart/related'
                 	);
if (-e "/data/celebrations/guavus_pics/$pik.jpg"){    
    	$msg->attach(Type => 'text/html',
                 Data => qq{ <body bgcolor="white"><FONT FACE="apple chancery" FONT SIZE='5' FONT COLOR="IndianRed">
                 		<b>Dear $name,<br><br>Guavus wishes for you all that you hope for, all that you dream of, all that makes you happy on this very special day.<br>May this day be filled with sunshine, smile, laughter and love...<br><br>A very Happy Birthday !!<br>
                             <img src="cid:Happy_Bday.jpg">
			     <img src="cid:$pik.jpg"> 
			     <br>Cheers<br>HR India</b>
                             </body></FONT> }
                 );

	$msg->attach(Type => 'image/jpeg',
                 Id   => 'Happy_Bday.jpg',
                 Path => '/data/celebrations/Happy_Bday.jpg',
                 );
        
$msg->attach(Type => 'image/jpeg',
                Id   => "$pik.jpg",
                 Path => "/data/celebrations/guavus_pics/$pik.jpg",
                 );

}else{

        $msg->attach(Type => 'text/html',
                 Data => qq{ <body bgcolor="white"><FONT FACE="apple chancery" FONT SIZE='5' FONT COLOR="IndianRed">
                                <b>Dear $name,<br><br>Guavus wishes for you all that you hope for, all that you dream of, all that makes you happy on this very special day.<br>May this day be filled with sunshine, smile, laughter and love...<br><br>A very Happy Birthday !!<br>
                             <img src="cid:Happy_Bday.jpg">
                             <br>Cheers<br>HR India</b>
                             </body></FONT> }
                 );

        $msg->attach(Type => 'image/jpeg',
                 Id   => 'Happy_Bday.jpg',
                 Path => '/data/celebrations/Happy_Bday.jpg',
                 );
}

        $msg->send;

}

			

			if (($doj_date == $day) && ($doj_mnth eq $mon) && ($doj_yr != $yr)){
				print OUT "$run_date Anniversary : matched DOJ $email1 $name $doj_date $doj_mnth \n";
				
				$yr_diff = $yr - $doj_yr;
				$pik=$name;
				$pik=~ s/\s/_/g;
			
        my $msg = MIME::Lite->new(
                 To      =>"gaurav.babbar@guavus.com",
		Bcc => "$bcc",
                 #from =>'CELEBRATIONS@guavus.com',
                 from =>'celebration.mail@guavus.com',
                 Subject =>"Congratulations $name on completion of $yr_diff Years !!",
                 Disposition =>'inline',
                 Type    =>'multipart/related'
                 );
   
if (-e "/data/celebrations/guavus_pics/$pik.jpg"){ 
        $msg->attach(Type => 'text/html',
                 Data => qq{ <body bgcolor="white"><FONT FACE="apple chancery" FONT SIZE='5' FONT COLOR="IndianRed">
                                <b>Dear $name,<br><br>Congratulations on completion of $yr_diff wonderful years with Guavus.<br>As you accomplish this step in this fruitful professional journey, we all appreciate and congratulate you on the same.<br>Coming year is a chance for making another step in the right direction and to do even better than before.<br><br>
                             <img src="cid:YearOfEx.png">
			     <img src="cid:$pik.jpg">
                             <br>Cheers<br>HR India</b>
                             </body></FONT> }                 
			);

        $msg->attach(Type => 'image/jpeg',
                 Id   => 'YearOfEx.png',
                 Path => '/data/celebrations/YearOfEx.png',
                 );

	$msg->attach(Type => 'image/jpeg',
                Id   => "$pik.jpg",
                 Path => "/data/celebrations/guavus_pics/$pik.jpg",
                 );

}else{
        $msg->attach(Type => 'text/html',
                 Data => qq{ <body bgcolor="white"><FONT FACE="apple chancery" FONT SIZE='5' FONT COLOR="IndianRed">
                                <b>Dear $name,<br><br>Congratulations on completion of $yr_diff wonderful years with Guavus.<br>As you accomplish this step in this fruitful professional journey, we all appreciate and congratulate you on the same.<br>Coming year is a chance for making another step in the right direction and to do even better than before.<br><br>
                             <img src="cid:YearOfEx.png">
                             <br>Cheers<br>HR India</b>
                             </body></FONT> }     
                        );

        $msg->attach(Type => 'image/jpeg',
                 Id   => 'YearOfEx.png',
                 Path => '/data/celebrations/YearOfEx.png',
                 );

}
	$msg->send;
		
	}	

  }

}
close(OUT);
close(IN);
}

else {
while ($past_date >= 1 ){
 
$p_date=`date -d '$past_date day ago' +'%d'`;
$p_mnth=`date -d '$past_date day ago' +'%b'`;
$p_year=`date -d '$past_date day ago' +'%Y'`;
chomp($p_date);
chomp($p_mnth);
chomp($p_year);

open (OUT,">>/data/celebrations/out.log") || die $!;

open (IN,"/data/celebrations/list.csv") || die $! ;

while ($line=<IN>){    
        #$name = $sheet->{Cells}[$row][2]{Val};
        #$sr_name = $sheet->{Cells}[$row][3]{Val};
           # $email = $sheet->{Cells}[$row][8]{Val};
            #$email='gaurav.babbar@guavus.com';

            #$doj = $sheet->{Cells}[$row][6]{Val};
            #$dob = $sheet->{Cells}[$row][5]{Val};
                chomp($line);

                @temp=split(/,/,$line);    

                $name=$temp[0];
                chomp($name);
                $email=$temp[1];
                chomp($email);
                #$doj = $sheet->{Cells}[$row][6]{Val};
                #$dob = $sheet->{Cells}[$row][5]{Val};
                $dob=$temp[3];
                $doj=$temp[2];


        @a1=split(/-/,$dob);
        @a2=split(/-/,$doj);

        $doj_date=$a2[0];
        $doj_mnth=$a2[1];
        $doj_yr=$a2[2];


        $dob_date=$a1[0];
        $dob_mnth=$a1[1];

        if (($name) && ($email) && ($doj) && ($dob)) {
        

            if (($dob_date == $p_date) && ($dob_mnth eq $p_mnth)){    
                #my $msg = "";
		print OUT "$run_date Happy belated Bday : matched DOB $email1 $name $dob_date $dob_mnth \n";

		$pik=$name;
		$pik=~ s/\s/_/g;

    my $msg = MIME::Lite->new(
                 To      =>"gaurav.babbar@guavus.com",
        Bcc => "$bcc",
                 #from =>'CELEBRATIONS@guavus.com',
                 from =>'celebration.mail@guavus.com',
                 Subject =>"Belated Happy Birthday $name  : $p_date-$p_mnth !!!!",
                 Disposition =>'inline',
                 Type    =>'multipart/related'
                 );
 if(-e "/data/celebrations/guavus_pics/$pik.jpg"){   
        $msg->attach(Type => 'text/html',
                 Data => qq{ <body bgcolor="white"><FONT FACE="apple chancery" FONT SIZE='5' FONT COLOR="IndianRed">
                        <b>Dear $name,<br><br>Guavus wishes for you all that you hope for, all that you dream of, all that makes you happy on this very special day.<br>May this day be filled with sunshine, smile, laughter and love...<br><br>A very Happy Belated Birthday !!<br>
                             <img src="cid:Happy_Bday.jpg">
			    <img src="cid:$pik.jpg">
                 <br>Cheers<br>HR India</b>
                             </body></FONT> }
                 );

    $msg->attach(Type => 'image/jpeg',
                 Id   => 'Happy_Bday.jpg',
                 Path => '/data/celebrations/Happy_Bday.jpg',
                 );
	$msg->attach(Type => 'image/jpeg',
                Id   => "$pik.jpg",
                 Path => "/data/celebrations/guavus_pics/$pik.jpg",
                 );
}else{

        $msg->attach(Type => 'text/html',
                 Data => qq{ <body bgcolor="white"><FONT FACE="apple chancery" FONT SIZE='5' FONT COLOR="IndianRed"> 
                        <b>Dear $name,<br><br>Guavus wishes for you all that you hope for, all that you dream of, all that makes you happy on this very special day.<br>May this day be filled with sunshine, smile, laughter and love...<br><br>A very Happy Belated Birthday !!<br>
                             <img src="cid:Happy_Bday.jpg">
                 <br>Cheers<br>HR India</b> 
                             </body></FONT> }
                 );
        
    $msg->attach(Type => 'image/jpeg',
                 Id   => 'Happy_Bday.jpg',
                 Path => '/data/celebrations/Happy_Bday.jpg',
                 );
}
    $msg->send;

}
            
            if (($doj_date == $p_date) && ($doj_mnth eq $p_mnth) && ($doj_yr != $p_year)){
print OUT "$run_date anniversary belated : matched DOJ $email1 $name $doj_date $doj_mnth \n";

                $yr_diff = $yr - $doj_yr;
$pik=$name;
$pik=~ s/\s/_/g;

        my $msg = MIME::Lite->new(
                 To      =>"gaurav.babbar@guavus.com",
        Bcc => "$bcc",
                 #from =>'CELEBRATIONS@guavus.com',
                from =>'celebration.mail@guavus.com', 
                Subject =>"Belated Wishes : On Completion of $yr_diff Years : !!",
                 Disposition =>'inline',
                 Type    =>'multipart/related'
                 );
if (-e "/data/celebrations/guavus_pics/$pik.jpg"){    
        $msg->attach(Type => 'text/html',
                 Data => qq{ <body bgcolor="white"><FONT FACE="apple chancery" FONT SIZE='5' FONT COLOR="IndianRed">
                                <b>Dear $name,<br><br>Congratulations on completion of $yr_diff wonderful years with Guavus.<br>As you accomplish this step in this fruitful professional journey, we all appreciate and congratulate you on the same.<br>Coming year is a chance for making another step in the right direction and to do even better than before.<br><br>
                             <img src="cid:YearOfEx.png">
				<img src="cid:$pik.jpg">
                             <br>Cheers<br>HR India</b>
                             </body></FONT> }                 
            );

        $msg->attach(Type => 'image/jpeg',
                 Id   => 'YearOfEx.png',
                 Path => '/data/celebrations/guavus_pics/YearOfEx.png',
                 );

$msg->attach(Type => 'image/jpeg',
                Id   => "$pik.jpg",
                 Path => "/data/celebrations/guavus_pics/$pik.jpg",
                 );

}else{

        $msg->attach(Type => 'text/html',
                 Data => qq{ <body bgcolor="white"><FONT FACE="apple chancery" FONT SIZE='5' FONT COLOR="IndianRed">
                                <b>Dear $name,<br><br>Congratulations on completion of $yr_diff wonderful years with Guavus.<br>As you accomplish this step in this fruitful professional journey, we all appreciate and congratulate you on the same.<br>Coming year is a chance for making another step in the right direction and to do even better than before.<br><br>
                             <img src="cid:YearOfEx.png">
                             <br>Cheers<br>HR India</b>
                             </body></FONT> }
            );

        $msg->attach(Type => 'image/jpeg',
                 Id   => 'YearOfEx.png',
                 Path => '/data/celebrations/guavus_pics/YearOfEx.png',
                 );

}
        $msg->send;
            }       
            
            

        }

}

$past_date--;

}
close(OUT);
close(IN);
}
