#!/bin/bash

if [ -f /data/celebrations/list.csv ]
then
	rm -f /data/celebrations/list.csv
fi

/data/celebrations/ldap_parser.pl /data/celebrations/gurgaon_list > /data/celebrations/list.csv
/data/celebrations/ldap_parser.pl /data/celebrations/abad_list >> /data/celebrations/list.csv


