{
 	echo "From: celebrations.mail@guavus.com"
        echo "To: ankur.gupta@guavus.com"
        echo "MIME-Version: 1.0"
        echo "Subject: Email Subject1"
        echo "Content-Type: multipart/mixed; boundary=\"FILEBOUNDARY\""
        echo
        echo "--FILEBOUNDARY"
        echo "Content-Type: multipart/alternative; boundary=\"MSGBOUNDARY\""
        echo

        echo "--MSGBOUNDARY"
        echo "Content-Type: text/html; charset=iso-8859-1"
        echo "Content-Disposition: inline"
        echo "<html>"
        echo '<body bgcolor="white"><FONT FACE="apple chancery" FONT SIZE="5" FONT COLOR="IndianRed">'
        echo "<b>Dear $name,<br><br>Guavus wishes for you all that you hope for, all that you dream of, all that makes you happy on this very special day.<br>May this day be filled with sunshine, smile, laughter and love...<br><br>A very Happy Birthday !!<br>"
	echo "<font face=verdana size=2>Tick mark:- </font>"
        echo "<img src=\"cid:tickjpeg\" /><br>"
        echo "<br>Cheers<br>HR India</b>"
        echo "</body></html>"
        echo "--MSGBOUNDARY--"

        echo
        echo "--FILEBOUNDARY"
	echo "Content-Type: image/jpeg"
        echo "Content-Disposition: inline; filename=\"Happy_Bday.jpg\""
        echo "Content-Transfer-Encoding: base64"
        echo "Content-Id: <tickjpeg>"
        echo
        base64 Happy_Bday.jpg
        echo

        echo "--FILEBOUNDARY--"
} | /usr/lib/sendmail -t -v
