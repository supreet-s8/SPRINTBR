#!/usr/bin/perl


use Data::Dumper;

open(FH, "<./old-pre-mig-dl.txt");
#open(OUT3,"> temp.txt");

my $old={};
# DisplayName,RecipientType,Primary SMTP address,Distribution Group,Distribution Group Primary SMTP address,Distribution Group Managers
foreach my $ln_old (<FH>) {

	my (@values)=split(/,/,$ln_old);

	my (@managers)=split(/;/,$values[5]);
	chomp (@managers);
	my @managersonly=();
	foreach $manager (@managers) {

		my (@man)=split (/\//,$manager);
		push (@managersonly, "$man[$#man]");

	}

#print OUT3 "$values[0],$values[1],$values[2],$values[3],$values[4],@managersonly\n";
	
	#foreach my $fields (@values) {

		#push (@old[{$values[0]}->{Groups}], $values[1]);
		#push (@old{$values[0]}[Groups], $values[1]);

		#push (@{$old{$values[0]}{Groups}}, $values[3]);
	 	#if (! $old{$values[0]}{Groups}{$values[3]}{email} ) {
                        #$old{$values[0]}{Groups}{$values[3]}{email}=$values[4];
			push(@{$old{$values[0]}{Groups}{$values[3]}{email}},$values[4]);
                #}
		if (! $old{$values[0]}{Groups}{$values[3]}{managers} ) {

			push(@{$old{$values[0]}{Groups}{$values[3]}{managers}},@managersonly);
                        #$old{$values[0]}{Groups}{$values[3]}{managers}=$values[5];
                }
   		if (! $old{$values[0]}{RecipientType} ) {
			$old{$values[0]}{RecipientType}=$values[1];
		}
		 #if (! $old{$values[0]}{PrimarySMTP} ) {
                 #       $old{$values[0]}{PrimarySMTP}=$values[2];
                #}
		if (!grep(/^$values[2]$/,@{$old{$values[0]}{PrimarySMTP}})) {
		push(@{$old{$values[0]}{PrimarySMTP}}, $values[2]);
		}
		
}

close FH;



#print Dumper %old;

open(FH2, "<./new-mig-dl.txt");

open(OUT1,"> diff.csv");
#open(OUT2,"> log.txt");
#open(OUT3,"> temp.txt");


print "DisplayName,RecipientType_Old,RecipientType_New,RecipientType_MatchResult,PrimarySMTP_Old,PrimarySMTP_New,PrimarySMTP_MatchResult,Groups_Old,Groups_New,Groups_Old,Groups_MatchResult,GroupPrimarySMTP_Old,GroupPrimarySMTP_New,GroupPrimarySMTP_MatchResult,GroupManagers_Old,GroupManagers_New,GroupManagers_MatchResult\n";
foreach $new_ln (<FH2>) {

        my (@valueN)=split(/,/,$new_ln);
        my (@managersN)=split(/;/,$valueN[5]);
        chomp (@managersN);
        my @managersonlyN=();
        foreach $managerN (@managersN) {

                my (@manN)=split (/\//,$managerN);
                push (@managersonlyN, $manN[$#manN]);

        }


   if ($old{$valueN[0]}) {
	#print "User ID : $valueN[0]\n---------------------------------------------\nCOLUMN,OLD VALUE,NEW VALUE,MATCH RESULT \n";
	$string = "$valueN[0],";
	if ($valueN[1] ne $old{$valueN[0]}{RecipientType}) {
	#	print "RecipientType $valueN[1] does not match for User ID: $valueN[0]\n";
		$string .=  "$old{$valueN[0]}{RecipientType},$valueN[1],NO,";
	}else {
		$string .= "$old{$valueN[0]}{RecipientType},$valueN[1],YES,";
	}
	

	#if ($valueN[2] ne $old{$valueN[0]}{PrimarySMTP}) {
	#	print "PrimarySMTP $valueN[2] does not match for User ID: $valueN[0]\n";
	#}

	if (! grep(/^$valueN[2]$/, @{$old{$valueN[0]}{PrimarySMTP}})) {
		#print "PrimarySMTP $valueN[2] does not exists for User ID: $valueN[0]\n";
		$string .= "@{$old{$valueN[0]}{PrimarySMTP}},$valueN[2],NO,";
	} else {

		 $string .= "@{$old{$valueN[0]}{PrimarySMTP}},$valueN[2],YES,";
	}
	
	if (! $old{$valueN[0]}{Groups}{$valueN[3]}) {
		#print "Group $valueN[3] does not exist for User ID: $valueN[0]\n";
		$string .=  "NA,$valueN[3],NO,";
	} else {
		#my @grp= keys %{$old{$valueN[0]}{Groups}};
		#chomp @grp;
		#chomp $valueN[3];
		#if (grep(/^$valueN[3]/, @grp)) {
		$string .= "$valueN[3],$valueN[3],YES,";
		#}
		if (! grep( /^$valueN[4]$/, @{$old{$valueN[0]}{Groups}{$valueN[3]}{email}})) {
			#print "Distribution Group $valueN[3] primary SMTP Address does not Exists \"$valueN[4]\"\n"; 
			#print OUT1 "$valueN[0],$valueN[1],$valueN[2],@{$old{$valueN[0]}{Groups}{$valueN[3]}{email}},$valueN[3],N,$valueN[4],@managersN\n"; 
			$string .= "@{$old{$valueN[0]}{Groups}{$valueN[3]}{email}},$valueN[4],NO,";
		} else {
			$string .= "@{$old{$valueN[0]}{Groups}{$valueN[3]}{email}},$valueN[4],YES,";

		}
		foreach my $managerName (@managersonlyN) {
		if (! grep( /^$managerName$/, @{$old{$valueN[0]}{Groups}{$valueN[3]}{managers}}) ) {
			#print "Distribution Group $valueN[3] manager \"$managerName\" does not exists in old list. For User: $valueN[0] \n";
			print "$string,@{$old{$valueN[0]}{Groups}{$valueN[3]}{managers}},$managerName,NO\n";
		} else {
			print "$string,@{$old{$valueN[0]}{Groups}{$valueN[3]}{managers}},$managerName,YES\n";
		}
		}
	}

    } else {
	#print "User ID : $valueN[0]\n COLUMN, OLD VALUE, NEW VALUE, MATCH RESULT \n---------------------------------------------\n";
	print "$valueN[0],,$valueN[1],NO,,$valueN[2],NO,,$valueN[3],NO,,$valueN[4],NO,,$valueN[5],NO\n";
#DisplayName,RecipientType_Old,RecipientType_New,RecipientType_MatchResult,PrimarySMTP_Old,PrimarySMTP_New,PrimarySMTP_MatchResult,Groups_Old,Groups_New,Groups_Old,Groups_MatchResult,GroupPrimarySMTP_Old,GroupPrimarySMTP_New,GroupPrimarySMTP_MatchResult,GroupManagers_Old,GroupManagers_New,GroupManagers_MatchResult
    }
	#print "---------------------------------------------\n";

}

close FH2;
close OUT1;
close OUT2;
